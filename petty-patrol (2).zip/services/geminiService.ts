import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult, AnalysisType } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const SYSTEM_INSTRUCTION = `
You are an AI assistant for the 'Petty Patrol' app. Your job is to analyze images uploaded by users.
The image will either contain:
1. A vehicle License Plate (from any region, but likely US).
2. A QR Code.
3. Neither/Invalid (selfies, landscapes, random objects, blurry unreadable images).

If it is a License Plate:
- Extract the alphanumeric text.

If it is a QR Code:
- Extract the encoded text content.

Response Rules:
- Return ONLY JSON.
- If unsure, mark as INVALID.
- Be lenient with License Plate visibility, but if it's completely unreadable, mark INVALID.
`;

export const analyzeImage = async (base64Image: string, mimeType: string): Promise<AnalysisResult> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: mimeType,
              data: base64Image
            }
          },
          {
            text: "Analyze this image. Is it a license plate or a QR code? Return the JSON object."
          }
        ]
      },
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            type: {
              type: Type.STRING,
              enum: [AnalysisType.LICENSE_PLATE, AnalysisType.QR_CODE, AnalysisType.INVALID],
              description: "The type of object detected."
            },
            value: {
              type: Type.STRING,
              description: "The extracted text from the license plate or QR code. Empty string if INVALID."
            },
            confidence: {
              type: Type.NUMBER,
              description: "Confidence score between 0 and 1."
            }
          },
          required: ["type", "value", "confidence"]
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from Gemini");

    return JSON.parse(text) as AnalysisResult;

  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    return {
      type: AnalysisType.INVALID,
      value: "Error analyzing image",
      confidence: 0
    };
  }
};
