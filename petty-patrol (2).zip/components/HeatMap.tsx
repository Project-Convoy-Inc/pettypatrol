import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import { MOCK_HEAT_POINTS } from '../constants';
import { LicensePlateReport } from '../types';

interface HeatMapProps {
  reports?: LicensePlateReport[];
}

const HeatMap: React.FC<HeatMapProps> = ({ reports = [] }) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);

  useEffect(() => {
    if (!mapContainerRef.current) return;

    // Initialize Map only once
    if (!mapInstanceRef.current) {
      mapInstanceRef.current = L.map(mapContainerRef.current, {
        center: [25.774, -80.133], // Miami Beach center
        zoom: 13,
        zoomControl: false, // Cleaner UI
        attributionControl: false
      });

      // Add CartoDB Dark Matter tile layer for that "night chaos" feel, or Voyager for clean look
      // Using OpenStreetMap standard for high visibility per request
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
      }).addTo(mapInstanceRef.current);
    }

    const map = mapInstanceRef.current;

    // Clear existing layers (except tiles)
    map.eachLayer((layer) => {
      if (layer instanceof L.Circle || layer instanceof L.Marker) {
        map.removeLayer(layer);
      }
    });

    // Prepare Data
    const userPoints = reports
      .filter(r => r.coordinates)
      .map(r => ({
        lat: r.coordinates!.lat,
        lng: r.coordinates!.lng,
        intensity: 10,
        isLegendary: r.behaviors.length >= 4
      }));

    const allPoints = [...MOCK_HEAT_POINTS, ...userPoints];

    // Draw Heat Circles
    allPoints.forEach(p => {
      const color = (p as any).isLegendary ? 'gold' : '#dc2626'; // Red for standard, Gold for legendary
      const opacity = (p as any).isLegendary ? 0.8 : 0.4;
      const radius = (p as any).isLegendary ? 200 : 120;

      L.circle([p.lat, p.lng], {
        color: 'transparent',
        fillColor: color,
        fillOpacity: opacity,
        radius: radius
      }).addTo(map);

      // Pulse ring for legendary
      if ((p as any).isLegendary) {
         L.circle([p.lat, p.lng], {
            color: 'gold',
            fillColor: 'transparent',
            weight: 2,
            radius: 300
         }).addTo(map);
      }
    });
    
    // Invalidate size to ensure tiles load correctly if container resized
    setTimeout(() => {
        map.invalidateSize();
    }, 100);

    // Cleanup not strictly necessary for singleton ref in this lifecycle, 
    // but good practice if component unmounts fully
    return () => {
       // We keep the map instance to avoid re-initializing on simple re-renders
    };

  }, [reports]);

  return (
    <div className="w-full h-[400px] bg-zinc-100 rounded-3xl overflow-hidden shadow-sm relative border border-zinc-200">
      <div className="absolute top-4 left-4 z-[400] bg-white/90 backdrop-blur px-3 py-1 rounded-full text-xs font-bold text-zinc-500 shadow-sm border border-zinc-200">
        LIVE CHAOS MAP
      </div>
      <div ref={mapContainerRef} className="w-full h-full z-0" />
    </div>
  );
};

export default HeatMap;