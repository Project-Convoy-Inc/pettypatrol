import React from 'react';
import { ViewState } from '../types';
import { Home, Ticket, Activity, Shield, Settings } from 'lucide-react';

interface BottomNavProps {
  currentView: ViewState;
  onNavigate: (view: ViewState) => void;
}

const BottomNav: React.FC<BottomNavProps> = ({ currentView, onNavigate }) => {
  const navItems = [
    { view: ViewState.HOME, label: 'Home', icon: <Home size={24} /> },
    { view: ViewState.DEALS, label: 'Deals', icon: <Ticket size={24} /> },
    { view: ViewState.LIVE, label: 'Live', icon: <Activity size={24} /> },
    { view: ViewState.BADGES, label: 'Badges', icon: <Shield size={24} /> },
    { view: ViewState.SETTINGS, label: 'Settings', icon: <Settings size={24} /> },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-zinc-100 pb-safe pt-2 px-6 pb-6 shadow-[0_-4px_20px_rgba(0,0,0,0.05)] z-50">
      <div className="flex justify-between items-center max-w-md mx-auto">
        {navItems.map((item) => {
          const isActive = currentView === item.view;
          return (
            <button
              key={item.label}
              onClick={() => onNavigate(item.view)}
              className={`flex flex-col items-center gap-1 transition-colors ${
                isActive ? 'text-red-600' : 'text-zinc-400 hover:text-zinc-600'
              }`}
            >
              <div className={`${isActive ? 'scale-110' : ''} transition-transform duration-200`}>
                {item.icon}
              </div>
              <span className="text-[10px] font-bold tracking-wide uppercase">{item.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default BottomNav;